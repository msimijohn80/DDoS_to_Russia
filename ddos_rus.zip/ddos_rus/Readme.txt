
1. Run "Start_ddos" or "Start_windows10" (for Windows 10);

2. Click "Start Kremlin DDoS" button;

3. Click "Stop" at any time.
